import os
import sys
import time
import re
import threading
import json
from datetime import datetime
import pyfiglet
from zlapi import ZaloAPI, ThreadType
from zlapi.models import Message
import config

do, luc, vang, xduong, end = "\033[1;31m", "\033[1;32m", "\033[1;33m", "\033[1;34m", "\033[0m"
ndp_tool = f"{do}[🤖] {end}"
ZALO_GROUP_LINK_REGEX = r"https://zalo\.me/g/[a-zA-Z0-9]+"
SETTINGS_FILE = "settings.json"
MESSAGE_FILE = "message.txt"

spreader_thread = None
is_spreading_active = threading.Event()
spreader_state = {"status": "Stopped", "message": "Đã dừng.", "rest_end_time": 0}
file_lock = threading.Lock()
state_lock = threading.Lock()

class AutoBot(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.processed_links, self.auto_join_enabled = set(), True

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        if not self.auto_join_enabled: return
        try:
            if not isinstance(message_object.content, str): return
            links = re.findall(ZALO_GROUP_LINK_REGEX, message_object.content)
            if not links: return
            for link in links:
                if link in self.processed_links: continue
                self.processed_links.add(link)
                try: self.joinGroup(link)
                except Exception: pass
        except Exception: pass

def load_message_from_file():
    if not os.path.exists(MESSAGE_FILE):
        with open(MESSAGE_FILE, 'w', encoding='utf-8') as f: f.write(config.DEFAULT_SPREAD_MESSAGE)
        return config.DEFAULT_SPREAD_MESSAGE
    try:
        with open(MESSAGE_FILE, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            return content if content else "[Nội dung trong message.txt đang trống]"
    except Exception: return "[Lỗi đọc message.txt]"

def load_settings():
    with file_lock:
        default = {
            'card_uid': None, 'card_phone': None, 'spread_with_card': False, 'rest_time': 40,
            'auto_join': True, 'is_spreader_on': False, 'whitelist_groups': []
        }
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, 'r', encoding='utf-8') as f: loaded = json.load(f)
                default.update(loaded)
            except (json.JSONDecodeError, UnicodeDecodeError): pass
        return default

def save_settings(settings):
    with file_lock:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=4, ensure_ascii=False)

def banner():
    try: terminal_width = os.get_terminal_size().columns
    except OSError: terminal_width = 80
    info = [{"label": "👑 Admin", "value": "TŨN THÚI", "color": luc}, {"label": "📱 FACEBOOK", "value": "THUI TŨN (TŨN THÚI)", "color": do}]
    if terminal_width < 75:
        title = "TTHUI ZALO TOOL"
        print(f"{xduong}{'='*terminal_width}{end}\n{luc}{title.center(terminal_width)}{end}\n{xduong}{'='*terminal_width}{end}")
        for line in info: print(f"{line['color']}{line['label']:<12}: {line['value']}{end}")
        print(f"{xduong}{'-'*terminal_width}{end}")
    else:
        fig = pyfiglet.Figlet(font='slant')
        print(f"{xduong}{fig.renderText('TThui Zalo Tool')}{end}")
        max_len = max(len(f"  {line['label']} : {line['value']}  ") for line in info)
        print(f"{xduong}╔{'═' * max_len}╗{end}")
        for line in info:
            text = f"  {line['label']} : {line['value']}"
            print(f"{xduong}║{line['color']}{text}{' ' * (max_len - len(text))}{xduong}║{end}")
        print(f"{xduong}╚{'═' * max_len}╝{end}")

def clear_screen(): os.system("cls" if os.name == "nt" else "clear")

def auto_spreader_worker(client):
    global spreader_state
    with state_lock: spreader_state.update({"status": "Running", "message": "Luồng rải tin đã bắt đầu."})
    while not is_spreading_active.is_set():
        try:
            settings, message_content = load_settings(), load_message_from_file()
            with state_lock: spreader_state.update({"status": "Running", "message": "Bắt đầu chu kỳ rải tin mới..."})
            card_avatar_url = None
            if settings['spread_with_card'] and settings['card_uid']:
                try:
                    user_info, profile = client.fetchUserInfo(settings['card_uid']), None
                    if user_info: profile = user_info.changed_profiles.get(settings['card_uid'])
                    if profile and profile.get('avatar'): card_avatar_url = profile['avatar']
                except Exception: pass
            groups_obj = client.fetchAllGroups()
            if not groups_obj or not groups_obj.gridVerMap:
                with state_lock: spreader_state['message'] = "Không tìm thấy nhóm nào."
            else:
                group_ids, whitelist = list(groups_obj.gridVerMap.keys()), settings.get('whitelist_groups', [])
                total_groups, success_count, skipped_count = len(group_ids), 0, 0
                for group_id in group_ids:
                    if is_spreading_active.is_set():
                        with state_lock: spreader_state['message'] = "Đã nhận lệnh dừng."; break
                    if group_id in whitelist:
                        skipped_count += 1; continue
                    try:
                        client.send(Message(text=message_content), group_id, ThreadType.GROUP)
                        if settings['spread_with_card'] and card_avatar_url:
                            client.sendBusinessCard(settings['card_uid'], card_avatar_url, group_id, ThreadType.GROUP, phone=settings['card_phone'])
                        success_count += 1
                    except Exception: pass
                    time.sleep(2)
                report = f"Hoàn thành: Gửi {success_count}, Bỏ qua {skipped_count}/{total_groups} nhóm."
                print(f"\n{luc}[BÁO CÁO] {report}{end}"); time.sleep(3)
                with state_lock: spreader_state['message'] = report
            if is_spreading_active.is_set(): break
            with state_lock: spreader_state.update({"status": "Resting", "rest_end_time": time.time() + settings['rest_time'] * 60})
            rest_duration, start_rest = settings['rest_time'] * 60, time.time()
            while time.time() - start_rest < rest_duration:
                if is_spreading_active.is_set(): break
                time.sleep(1)
            if is_spreading_active.is_set(): break
        except Exception as e:
            with state_lock: spreader_state['message'] = f"Lỗi nghiêm trọng: {e}"; is_spreading_active.set()
    with state_lock: spreader_state.update({"status": "Stopped", "message": "Đã dừng."})

def list_friends_feature(client):
    try:
        print(f"\n{vang}Đang tải danh sách bạn bè...{end}")
        friends = client.fetchAllFriends()
        if not friends: print(f"{vang}Không tìm thấy bạn bè nào.{end}"); return
        print(f"\n{luc}🎉 Tìm thấy tổng cộng {len(friends)} bạn bè:{end}\n{xduong}{'-'*50}{end}")
        for i, friend in enumerate(friends):
            name, uid = friend.zaloName or "Không có tên", friend.userId
            print(f"{luc}{i+1:03d}.{end} {vang}Tên:{end} {name:<25} - {vang}UID:{end} {uid}")
        print(f"{xduong}{'-'*50}{end}")
    except Exception as e: print(f"{do}❌ Lỗi khi tải danh sách bạn bè: {e}{end}")

def list_groups_feature(client):
    try:
        print(f"\n{vang}Đang tải danh sách nhóm...{end}")
        groups_obj = client.fetchAllGroups()
        if not groups_obj or not hasattr(groups_obj, 'gridVerMap'): print(f"{vang}Không tìm thấy nhóm nào.{end}"); return
        group_ids = list(groups_obj.gridVerMap.keys())
        print(f"\n{luc}🎉 Tìm thấy tổng cộng {len(group_ids)} nhóm:{end}\n{xduong}{'-'*40}{end}")
        for i, group_id in enumerate(group_ids):
            try:
                info = client.fetchGroupInfo(group_id); name = info.gridInfoMap[group_id]['name']
            except Exception: name = "<Không lấy được tên>"
            print(f"{luc}{i+1}{end}\n  {vang}|- Tên nhóm:{end} {name}\n  {vang}|- ID nhóm: {end} {group_id}")
        print(f"{xduong}{'-'*40}{end}")
    except Exception as e: print(f"{do}❌ Lỗi khi tải danh sách nhóm: {e}{end}")

def export_groups_to_file(client):
    try:
        print(f"\n{vang}Đang xuất danh sách nhóm ra file 'danh_sach_nhom.txt'...{end}")
        groups_obj = client.fetchAllGroups()
        if not groups_obj or not hasattr(groups_obj, 'gridVerMap'):
            print(f"{do}❌ Không tìm thấy nhóm nào để xuất.{end}"); return
        group_ids = list(groups_obj.gridVerMap.keys())
        with open("danh_sach_nhom.txt", 'w', encoding='utf-8') as f:
            f.write(f"Danh sách {len(group_ids)} nhóm lúc: {datetime.now().strftime('%H:%M:%S %d/%m/%Y')}\n{'='*40}\n\n")
            for i, group_id in enumerate(group_ids):
                try: info = client.fetchGroupInfo(group_id); name = info.gridInfoMap[group_id]['name']
                except Exception: name = "<Không lấy được tên>"
                f.write(f"{i+1}\n|- Tên nhóm: {name}\n|- ID nhóm: {group_id}\n{'-' * 20}\n")
        print(f"{luc}✅ Xuất thành công! Vui lòng kiểm tra file 'danh_sach_nhom.txt'.{end}")
    except Exception as e: print(f"{do}❌ Lỗi khi xuất file: {e}{end}")

def manage_whitelist_feature(settings):
    while True:
        clear_screen(); banner()
        whitelist = settings.get('whitelist_groups', [])
        print(f"{luc}--- Quản lý Whitelist Nhóm ---{end}")
        if not whitelist: print(f"{vang}Whitelist hiện đang trống.{end}")
        else:
            print(f"{vang}Các nhóm sau sẽ không bị rải tin:{end}")
            for i, gid in enumerate(whitelist): print(f"  {i+1}. {gid}")
        print(f"\n{luc}1.{end} Thêm ID\n{luc}2.{end} Xóa ID\n{do}0.{end} Quay lại")
        choice = input(f"{ndp_tool}Lựa chọn: ").strip()
        if choice == '1':
            gid = input(f"{ndp_tool}Nhập ID nhóm cần thêm: ").strip()
            if gid.isdigit():
                if gid not in whitelist: whitelist.append(gid); print(f"{luc}✅ Đã thêm.{end}")
                else: print(f"{vang}⚠️ ID đã có.{end}")
            else: print(f"{do}❌ ID không hợp lệ.{end}")
        elif choice == '2':
            gid = input(f"{ndp_tool}Nhập ID nhóm cần xóa: ").strip()
            if gid in whitelist: whitelist.remove(gid); print(f"{luc}✅ Đã xóa.{end}")
            else: print(f"{do}❌ Không tìm thấy ID.{end}")
        elif choice == '0': break
        else: print(f"{do}❌ Lựa chọn không hợp lệ.{end}")
        save_settings(settings); time.sleep(1.5)

def get_spreader_status_text():
    with state_lock:
        status, end_time = spreader_state['status'], spreader_state['rest_end_time']
    if status == 'Stopped': return f"{do}Đã dừng{end}"
    if status == 'Running': return f"{luc}Đang rải tin...{end}"
    if status == 'Resting':
        remaining = end_time - time.time()
        if remaining > 0:
            mins, secs = divmod(int(remaining), 60)
            end_time_str = datetime.fromtimestamp(end_time).strftime('%H:%M:%S %d/%m/%Y')
            return f"{vang}Nghỉ, rải lại lúc {end_time_str} ({mins:02d}:{secs:02d} nữa){end}"
    return f"{do}Không xác định{end}"

def main():
    global spreader_thread, spreader_state
    clear_screen(); banner()
    if not config.IMEI or config.IMEI == "DIEN_IMEI_CUA_BAN_VAO_DAY":
        print(f"{do}Lỗi: Vui lòng điền IMEI/COOKIE vào 'config.py'.{end}"); sys.exit(1)
    try:
        print(f"{vang}Đang đăng nhập...{end}")
        client = AutoBot(phone='</>', password='</>', imei=config.IMEI, session_cookies=config.COOKIE, auto_login=True)
        my_info = client.fetchAccountInfo()
        if not (my_info and my_info.profile): raise Exception("Cookie không hợp lệ hoặc đã hết hạn.")
        acc_name, acc_uid = my_info.profile.get('zaloName', 'Không rõ'), my_info.profile.get('userId', 'Không rõ')
        print(f"{luc}✅ Đăng nhập thành công!{end}"); time.sleep(2)
    except Exception as e: print(f"{do}❌ Lỗi đăng nhập: {e}{end}"); return

    spreader_settings = load_settings()
    client.auto_join_enabled = spreader_settings.get('auto_join', True)
    threading.Thread(target=client.listen, daemon=True).start()
    if spreader_settings.get('is_spreader_on'):
        print(f"{luc}Trạng thái Auto-Rải đang Bật. Tự động khởi động lại luồng...{end}")
        is_spreading_active.clear()
        spreader_thread = threading.Thread(target=auto_spreader_worker, args=(client,), daemon=True)
        spreader_thread.start(); time.sleep(2)

    while True:
        clear_screen(); banner()
        message_content, auto_join_status = load_message_from_file(), f"{luc}Bật{end}" if client.auto_join_enabled else f"{do}Tắt{end}"
        card_mode_status, spreader_status_text = f"{luc}Bật{end}" if spreader_settings.get('spread_with_card') else f"{do}Tắt{end}", get_spreader_status_text()
        card_phone_display, display_message = spreader_settings.get('card_phone') or 'Chưa cài đặt', message_content.replace('\n', '↵')

        print(f"""{luc}
╔═══════════════════ CÀI ĐẶT ════════════════════╗
║ {vang}Tài khoản:     {end} {acc_name} ({acc_uid})
║ {vang}Nội dung:        {end} {display_message[:40]}
║ {vang}UID Card:        {end} {spreader_settings['card_uid'] or 'Chưa cài đặt'}
║ {vang}SĐT trên Card:    {end} {card_phone_display}
║ {vang}Rải Card:        {end} {card_mode_status}
║ {vang}Thời gian nghỉ:   {end} {spreader_settings['rest_time']} phút
║ {vang}Auto-Join:       {end} {auto_join_status}
║ {vang}Auto-Rải:        {end} {spreader_status_text}
╚═══════════════════════════════════════════════╝
╔══════════════════ MENU ══════════════════════╗
║ {vang}1.{end} Cài đặt UID Card      {vang}5.{end} {do}Bắt đầu/Dừng Auto-Rải{end}
║ {vang}2.{end} Cài đặt SĐT Card      {vang}6.{end} Xem danh sách nhóm
║ {vang}3.{end} Cài đặt Thời gian nghỉ  {vang}7.{end} Xem danh sách bạn bè
║ {vang}4.{end} Bật/Tắt chế độ Card    {vang}8.{end} Xuất DS nhóm ra file
║ {vang}9.{end} Quản lý Whitelist     {vang}10.{end} Bật/Tắt Auto-Join
║ {do}0.{end} Thoát
╚═══════════════════════════════════════════════╝""")
        try:
            choice = input(f"{ndp_tool}Chọn một chức năng: ").strip()
            if choice in ["1", "2", "3", "4", "10"]:
                if choice == "1":
                    new_uid = input(f"{ndp_tool}Nhập UID cho Card: ").strip()
                    if new_uid.isdigit(): spreader_settings['card_uid'] = new_uid
                    else: print(f"{do}❌ UID không hợp lệ.{end}"); time.sleep(1.5)
                elif choice == "2":
                    new_phone = input(f"{ndp_tool}Nhập SĐT/Văn bản trên Card (bỏ trống để xóa): ").strip()
                    spreader_settings['card_phone'] = new_phone if new_phone else None
                elif choice == "3":
                    new_time = input(f"{ndp_tool}Nhập số phút nghỉ: ").strip()
                    if new_time.isdigit() and int(new_time) > 0: spreader_settings['rest_time'] = int(new_time)
                    else: print(f"{do}❌ Thời gian không hợp lệ.{end}"); time.sleep(1.5)
                elif choice == "4": spreader_settings['spread_with_card'] = not spreader_settings.get('spread_with_card', False)
                elif choice == "10":
                    client.auto_join_enabled = not client.auto_join_enabled
                    spreader_settings['auto_join'] = client.auto_join_enabled
                save_settings(spreader_settings)
            elif choice == '5':
                if spreader_thread and spreader_thread.is_alive():
                    print(f"{vang}Đang gửi yêu cầu dừng Auto-Rải...{end}")
                    is_spreading_active.set(); spreader_thread.join()
                    spreader_settings['is_spreader_on'] = False
                else:
                    if spreader_settings['spread_with_card'] and not spreader_settings['card_uid']:
                        print(f"{do}❌ Vui lòng cài đặt UID cho Card trước.{end}"); time.sleep(2)
                    else:
                        is_spreading_active.clear()
                        spreader_thread = threading.Thread(target=auto_spreader_worker, args=(client,), daemon=True)
                        spreader_thread.start(); time.sleep(1)
                        spreader_settings['is_spreader_on'] = True
                save_settings(spreader_settings)
            elif choice == "6": list_groups_feature(client); input(f"\n{vang}Nhấn Enter để quay lại...{end}")
            elif choice == "7": list_friends_feature(client); input(f"\n{vang}Nhấn Enter để quay lại...{end}")
            elif choice == "8": export_groups_to_file(client); input(f"\n{vang}Nhấn Enter để quay lại...{end}")
            elif choice == "9": manage_whitelist_feature(spreader_settings)
            elif choice == "0":
                if spreader_thread and spreader_thread.is_alive():
                    print(f"{vang}Đang dừng luồng rải tin...{end}")
                    is_spreading_active.set(); spreader_thread.join()
                save_settings(spreader_settings)
                print(f"{vang}Đã lưu cài đặt. Cảm ơn đã sử dụng tool!{end}"); break
        except KeyboardInterrupt:
            if spreader_thread and spreader_thread.is_alive():
                is_spreading_active.set(); spreader_thread.join()
            save_settings(spreader_settings)
            print(f"\n{do}⛔ Đã lưu cài đặt và dừng chương trình.{end}"); break
if __name__ == "__main__":
    main()()